#!/usr/bin/python
# -*- coding: utf-8 -*-

### BEGIN LICENSE
# Copyright (C) 2013 ~ 2014 National University of Defense Technology(NUDT) & Kylin Ltd
# Author: Kobe Lee
#
# This program is free software: you can redistribute it and/or modify it
# under the terms of the GNU General Public License version 3, as published
# by the Free Software Foundation.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranties of
# MERCHANTABILITY, SATISFACTORY QUALITY, or FITNESS FOR A PARTICULAR
# PURPOSE.  See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program.  If not, see <http://www.gnu.org/licenses/>.
### END LICENSE


from gi.repository import Gtk

class DemoWindow(Gtk.Window):

    def __init__(self):
        Gtk.Window.__init__(self, title="UbuntuKylin Demo")

        label = Gtk.Label("Hello World!")

        self.add(label)



if __name__ == "__main__":
	demo = DemoWindow()
	demo.set_size_request(400,350)
	demo.connect("delete-event", Gtk.main_quit)
	demo.show_all()
	Gtk.main()
